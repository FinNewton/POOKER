from tkinter import *
import random as r

BUTTON_WIDTH = 3
BUTTON_HEIGHT = 2
NUM_BUTTONS = BUTTON_HEIGHT * BUTTON_WIDTH
NUM_QUESTIONS = 5


class SchoolTeReo:

    def __init__(self, parent):
        """Sets up the GUI and all relevant variables to be used
        throughout the class. Sets frame for the data about attempts but
        doesn't pack until later in code when information is gathered."""
        # Sets up important detail.
        self.correct_answer = "n/a"
        self.questions_left = NUM_QUESTIONS
        self.attempts = 1
        self.incorrect = []
        self.incorrect_button_pressed = []
        self.past_answers = []

        # Will display the current question being asked.
        self.question_label = Label(parent,
                                    text="Press start, to start the test.")
        self.question_label.grid(row=0, column=0)

        # Will let the user know how many questions are left.
        self.question_info_label = Label(
            parent,
            text=f"questions left: {str(self.questions_left)}")
        self.question_info_label.grid(row=0, column=1)

        # Will have the 6 different answer possibility.
        self.answer_frame = Frame(parent, height=300, width=300)
        self.answer_frame.grid(row=1, column=0, columnspan=5)

        # Sets up frame for all the stats about attempts.
        record_frame = Frame(parent)
        record_frame.grid(row=3, column=0, columnspan=5, sticky=E + W)

        # Sets up the 5 labels for each question.
        # Text will be configured and packed after each answered question.
        self.record_labels = []
        for i in range(NUM_QUESTIONS):
            self.record_labels.append(Label(record_frame, text=""))

        # Sets up the 6 different buttons for the answers.
        self.answer_buttons = []
        index = 0
        for i in range(BUTTON_HEIGHT):
            for x in range(BUTTON_WIDTH):
                self.answer_buttons.append(
                    Button(self.answer_frame, text="    N/a    ", padx=2.5,
                           pady=2.5, width=40))
                self.answer_buttons[index].grid(row=i, column=x, padx=10,
                                                pady=5)
                index += 1

        # Button to start the quiz.
        self.start_button = Button(parent, text="Start!",
                                   command=self.set_question)
        self.start_button.grid(row=2, column=0, columnspan=5, sticky=E + W)

    def set_question(self):
        """Will set the 6 possible answers to the corresponding button,
        5 false 1 correct, Will remove the start button once quiz started.
        Stores an event for each button when pressed
        to record the incorrect data. """
        # Sets up vars to use in function.
        correct_ans_loop = True
        index1 = 0

        # Unbinds the start button on first iteration.
        if self.questions_left == NUM_QUESTIONS:
            self.start_button.destroy()

        # Will save the 5 wrong possible answers.
        wrong_answers = []
        # Encoding is because the file was not opening properly and read line
        # was breaking, after testing I believe it to be due to macrons
        # but not 100% sure, this encoding fixes the issue.
        file = open("Translations.txt", encoding="utf8")
        lines = file.readlines()
        # Creates a list 1 less than the number of buttons,
        # as random values for wrong values answers.
        random_values = r.sample(range(0, len(lines)), NUM_BUTTONS - 1)

        # Creates correct answer.
        # Checks that the correct value isn't in the list of wrong words.
        # Checks that it's not already been a question in the quiz. 
        while correct_ans_loop:
            self.correct_answer = r.randint(0, len(lines) - 1)
            # checks it is not in list.
            if self.correct_answer not in random_values and \
                    self.correct_answer not in self.past_answers:
                # Remembers all the words which were correct
                # throughout the quiz to prevent dupes.
                self.past_answers.append(self.correct_answer)
                correct_ans_loop = False

        # Creates a list of the maori and english of all selected words.
        for line in lines:
            location = lines.index(line)
            word = line.split(",")
            if location in random_values:
                wrong_answers.append([word[0], word[1]])
            # appends the correct answer to the list as well.
            elif location == self.correct_answer:
                self.correct_answer = [word[0], word[1]]
                wrong_answers.append([word[0], word[1]])

        # will create a random location all 6 values.
        random_btn_locations = r.sample(range(0, NUM_BUTTONS), NUM_BUTTONS)
        for placement in random_btn_locations:
            # Creates an event when button is pressed
            # with the English and Maori of pressed button.
            self.answer_buttons[placement].configure(
                text=wrong_answers[index1][0])
            self.answer_buttons[placement].var = [wrong_answers[index1][0],
                                                  wrong_answers[index1][1]]
            self.answer_buttons[placement].bind("<Button-1>", self.answers)
            index1 += 1
        file.close()

        # Changes the GUI to tell the user the question.
        self.question_label.configure(
            text=f"What is '{self.correct_answer[1]}' in Maori?")

    def answers(self, event):
        """Will check if the inputted answer was correct or incorrect.
        if correct, will set a record how many attempts to get correct,
        then either set up next question or give
        summary on results. if incorrect will tell them they are incorrect."""
        word = event.widget.var
        # runs if the word is correct.
        if word[0] == self.correct_answer[0]:
            # Bad spacing for pep8 compliance. Line to long otherwise.
            # Creates a record of how many attempts to get correct.
            # Sets it to the label of the correct indexed label from beginning.
            self.record_labels[NUM_QUESTIONS - self.questions_left].configure(
                text=f"Question number"
                     f" {NUM_QUESTIONS - self.questions_left + 1}:"
                     f" Correct in {self.attempts} attempts.")
            self.record_labels[NUM_QUESTIONS - self.questions_left].pack()
            # changes to the next question and resets anything required.
            self.attempts = 1
            self.questions_left -= 1
            self.question_info_label.configure(
                text=f"Questions left: {str(self.questions_left)}")
            # Will set a new question if questions are left,
            # or say how they did and end GUI.
            if self.questions_left > 0:
                self.set_question()
                # Resets the incorrect buttons so if dupes come up they will
                # get counted for different question.
                self.incorrect_button_pressed = []
            else:
                self.summary()
        # run if the word is incorrect.
        else:
            self.question_info_label.configure(
                text=f"Incorrect  Questions left: {str(self.questions_left)}")
            # checks if it's the first time the question was incorrect.
            # If so adds correct answer to a list of incorrect questions.

            # Needs to add 1 attempt for every new button press.
            # Repeat incorrect doesn't count as additional attempt.
            if word[0] not in self.incorrect_button_pressed:
                self.incorrect_button_pressed.append(word[0])
                self.attempts += 1

            # Saves the maori and english of every correct answer
            # not guessed 1st attempt, used in summary.
            work_on = f"{self.correct_answer[1]} : {self.correct_answer[0]}"
            if work_on not in self.incorrect:
                # appends the maori then english translation of any
                # incorrect questions.
                self.incorrect.append(work_on)

    def summary(self):
        """Will tell the user how well they did on the test,
        What they did not do well at and need to improve at
         as well as what they did good at."""
        # Removes the buttons once test is over.
        for i in self.answer_buttons:
            i.destroy()

        # removes the last question from GUI.
        self.question_label.configure(text="")
        self.question_info_label.configure(text="")
        # creates a new label which will be used to give feedback,
        # .join to give formatting.
        improve = '\n'.join(self.incorrect)
        # runs if they got an answer wrong
        if len(self.incorrect) > 0:
            # To find the number they got right take away the amount
            # of incorrect values from the total possible.
            feedback_label = Label(
                self.answer_frame,
                text=f"You got {NUM_QUESTIONS - len(self.incorrect)} "
                     f"out of {NUM_QUESTIONS} correct in 1 go.\n"
                     f"\nYou should work on these words\n\n{improve}")
            feedback_label.pack()
        # Runs if they flawless the test.
        else:
            feedback_label = Label(
                self.answer_frame,
                text=f"YOU GOT ALL WORDS CORRECT CONGRATULATIONS!")
            feedback_label.pack()


if __name__ == "__main__":
    root = Tk()
    root.title("School Te Reo")
    SchoolTeReo(root)
    root.mainloop()
